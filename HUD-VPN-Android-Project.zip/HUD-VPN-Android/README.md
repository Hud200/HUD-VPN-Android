# H.U.D VPN — Android project (prototype 0.1.0)

A native Android VPN-client starter project using Kotlin + Jetpack Compose, designed for a sing-box/libbox engine.

## Included in this first scaffold
- H.U.D VPN branding and dashboard UI
- Light/dark theme toggle
- Initial profile list UI
- Basic share-link scheme detection for `vless://`, `vmess://`, `trojan://`, and `ss://`
- Android project structure and a libbox dependency declaration

## Important: current limitations
This is **not yet a working VPN client**. The Connect button is intentionally disabled. The current parser only classifies share-link schemes; it does not fully decode/validate credentials or generate sing-box JSON. No VPN tunnel is started.

The next engineering stage must implement and test:
1. Full share-link parsers (including VMess base64 JSON and Shadowsocks variants).
2. Conversion into a validated sing-box configuration.
3. libbox `CommandServer` / platform bridge and Android `VpnService` lifecycle.
4. Runtime permission/consent flow, foreground notification and stop/reconnect handling.
5. Persistent profile storage with sensitive values protected; redacted logs.
6. Device tests for DNS, IPv4/IPv6, routing, reconnect, battery/background behavior.

## Build
Open this folder in Android Studio (JDK 17 recommended), allow Gradle sync, then run the `app` configuration on an Android device/emulator. The first sync needs internet access to download dependencies. An APK can be generated from **Build > Build Bundle(s) / APK(s) > Build APK(s)** after Gradle sync succeeds.

## sing-box / licensing
The Android libbox binding is declared as `com.github.singbox-android:libbox:1.14.1`. Verify the current upstream release and build instructions before shipping. sing-box/libbox is GPL-3.0-or-later; distributing an app that includes it generally requires distributing the corresponding app source under a GPL-compatible license and retaining required notices. Review the exact upstream license and obligations before publication.

Upstream:
- https://github.com/singbox-android/libbox
- https://github.com/singbox-android/libbox/releases
- https://github.com/SagerNet/sing-box
