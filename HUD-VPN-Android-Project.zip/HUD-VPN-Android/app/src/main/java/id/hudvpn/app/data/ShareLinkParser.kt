package id.hudvpn.app.data

import android.net.Uri
import android.util.Base64

/**
 * Lightweight share-link classifier for the first UI prototype.
 * This is NOT a complete protocol parser and does not create sing-box JSON.
 * Full parsing and validation must be delegated to a tested sing-box config pipeline.
 */
object ShareLinkParser {
    fun parse(raw: String): ProxyProfile? {
        val value = raw.trim().lineSequence().firstOrNull { it.isNotBlank() } ?: return null
        val scheme = value.substringBefore("://", "").lowercase()
        val supported = setOf("vless", "vmess", "trojan", "ss")
        if (scheme !in supported) return null

        val name = when {
            scheme == "vmess" -> "VMess Server"
            else -> Uri.parse(value).fragment?.takeIf { it.isNotBlank() }
                ?.let { Uri.decode(it) } ?: "${scheme.uppercase()} Server"
        }
        return ProxyProfile(name = name, protocol = scheme, shareLink = value)
    }
}
