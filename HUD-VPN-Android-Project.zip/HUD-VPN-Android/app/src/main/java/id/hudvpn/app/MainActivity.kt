package id.hudvpn.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import id.hudvpn.app.data.ProxyProfile
import id.hudvpn.app.data.ShareLinkParser
import id.hudvpn.app.ui.HudTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HudTheme { HudHome() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HudHome() {
    var darkMode by remember { mutableStateOf(true) }
    var showImport by remember { mutableStateOf(false) }
    var linkText by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var profiles by remember { mutableStateOf(listOf<ProxyProfile>()) }
    var selected by remember { mutableStateOf<String?>(null) }
    var showInfo by remember { mutableStateOf(false) }

    HudTheme(darkTheme = darkMode) {
        val colors = MaterialTheme.colorScheme
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("H.U.D VPN", fontWeight = FontWeight.ExtraBold)
                            Text("SECURE CONNECTION CLIENT", style = MaterialTheme.typography.labelSmall,
                                color = colors.onSurfaceVariant)
                        }
                    },
                    actions = {
                        IconButton(onClick = { darkMode = !darkMode }) {
                            Text(if (darkMode) "☀" else "☾")
                        }
                        IconButton(onClick = { showInfo = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Info")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = colors.surfaceVariant),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier.size(74.dp).background(colors.primary.copy(alpha = .12f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Shield, null, tint = colors.primary, modifier = Modifier.size(38.dp))
                            }
                            Spacer(Modifier.height(16.dp))
                            Text("BELUM TERHUBUNG", style = MaterialTheme.typography.labelLarge,
                                color = colors.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Siap untuk terhubung", style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Pilih profil server terlebih dahulu. Mesin koneksi sedang dalam tahap integrasi.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = colors.onSurfaceVariant
                            )
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = { showInfo = true },
                                enabled = false,
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Icon(Icons.Default.Bolt, null)
                                Spacer(Modifier.width(8.dp))
                                Text("CONNECT")
                            }
                            Text("Koneksi VPN belum aktif pada build prototipe ini",
                                style = MaterialTheme.typography.labelSmall,
                                color = colors.error)
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("Konfigurasi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("${profiles.size} profil tersimpan", color = colors.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall)
                        }
                        FilledTonalButton(onClick = { showImport = true }) {
                            Icon(Icons.Default.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text("Import")
                        }
                    }
                }
                if (profiles.isEmpty()) {
                    item {
                        OutlinedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.History, null, tint = colors.onSurfaceVariant,
                                    modifier = Modifier.size(30.dp))
                                Spacer(Modifier.height(10.dp))
                                Text("Belum ada konfigurasi", fontWeight = FontWeight.SemiBold)
                                Text("Tekan Import untuk menambahkan tautan server.",
                                    color = colors.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                } else {
                    items(profiles, key = { it.id }) { profile ->
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth().clickable { selected = profile.id },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = if (selected == profile.id) colors.primaryContainer else colors.surface
                            )
                        ) {
                            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Shield, null, tint = colors.primary)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(profile.name, fontWeight = FontWeight.SemiBold)
                                    Text(profile.protocol.uppercase(), style = MaterialTheme.typography.labelSmall,
                                        color = colors.onSurfaceVariant)
                                }
                                IconButton(onClick = { profiles = profiles.filterNot { it.id == profile.id } }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Hapus profil")
                                }
                            }
                        }
                    }
                }
                item {
                    Text("H.U.D VPN • Versi 0.1.0 • Powered by sing-box",
                        style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                }
            }
        }

        if (showImport) {
            AlertDialog(
                onDismissRequest = { showImport = false; error = null },
                title = { Text("Import konfigurasi") },
                text = {
                    Column {
                        Text("Tempel tautan VLESS, VMess, Trojan, atau Shadowsocks.")
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = linkText, onValueChange = { linkText = it; error = null },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3, placeholder = { Text("vless://...") }
                        )
                        error?.let { Text(it, color = colors.error, style = MaterialTheme.typography.bodySmall) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val parsed = ShareLinkParser.parse(linkText)
                        if (parsed == null) {
                            error = "Tautan tidak dikenali. Periksa format konfigurasi."
                        } else {
                            profiles = profiles + parsed
                            selected = parsed.id
                            linkText = ""
                            error = null
                            showImport = false
                        }
                    }) { Text("Simpan") }
                },
                dismissButton = { TextButton(onClick = { showImport = false; error = null }) { Text("Batal") } }
            )
        }

        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                title = { Text("Tentang prototipe") },
                text = { Text("Tampilan, tema, dan validasi awal tautan sudah disiapkan. Integrasi libbox, izin Android VPN, penyimpanan aman, dan pengujian koneksi adalah tahap berikutnya.") },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Mengerti") } }
            )
        }
    }
}
