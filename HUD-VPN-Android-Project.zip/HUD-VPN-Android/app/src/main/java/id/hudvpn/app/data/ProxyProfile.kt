package id.hudvpn.app.data

import java.util.UUID

data class ProxyProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: String,
    val shareLink: String
)
