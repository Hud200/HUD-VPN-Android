package id.hudvpn.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HudDark = darkColorScheme(
    primary = Color(0xFF70D6C2),
    onPrimary = Color(0xFF00382F),
    secondary = Color(0xFF8BD8CA),
    background = Color(0xFF0B1113),
    surface = Color(0xFF111B1E),
    surfaceVariant = Color(0xFF1B292D)
)
private val HudLight = lightColorScheme(
    primary = Color(0xFF006B5B),
    onPrimary = Color.White,
    secondary = Color(0xFF286B60),
    background = Color(0xFFF5F8F7),
    surface = Color.White,
    surfaceVariant = Color(0xFFE4EFEC)
)

@Composable
fun HudTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) HudDark else HudLight,
        content = content
    )
}
